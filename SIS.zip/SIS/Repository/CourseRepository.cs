﻿using System;
using SIS.Model;

namespace SIS.Repository
{
	public class CourseRepository : iCourseRepository
	{

        Course course;
        Student student;
		public CourseRepository()
		{
		}

        public int AssignTeacher(Teacher teacher)
        {
            //clearing paramateres
            //cmd.Parameters.Clear()
            cmd.CommandText = "UPDATE Courses SET teacher_id = @tid WHERE course_id = @cid )";
            cmd.Parameters.AddWithValue("@teacher_id", teacher.teacherId);
            cmd.Parameters.AddWithValue("@cid",course.courseId );
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            int returnLeaseStatus = cmd.ExecuteNonQuery();
            return returnLeaseStatus;
        }

        public bool DisplayCourseInfo()
        {
            //Console.WriteLine($"Course ID: {course.courseId}");
            //Console.WriteLine($"Course Name: {course.courseName}");
            //Console.WriteLine($"Course Code: {course.courseCode}");
            //Console.WriteLine($"Instructor: {course.instructorName}");
            return true;

        }

        public List<Student> GetEnrollments() //error , logic correct
        {
            List<Student> students = new List<Student>();
            cmd.CommandText = "select concat(s.first_name + ' ' , s.last_name) as Students from Students s JOIN Enrollment e ON e.student_id = s.student_id WHERE course_id = @cid";
            cmd.Parameters.AddWithValue("@cid", course.courseId);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                student.studentId = (int)reader["student_id"]; //whyyyyy???
                student.firstName = (string)reader["first_name"];
                student.lastName = (string)reader["last_name"];
                student.dob = (DateOnly)reader["date_of_birth"]; //error can be here
                student.email = (string)reader["email"];
                student.phoneNumber = (int)reader["phone_number"];
                students.Add(student);
            }
            return students;
        }

        public string GetTeacher()
        {
            cmd.CommandText = "select concat(t.first_name + ' ' , t.last_name) as Teacher_Name from Teacher t JOIN Courses c ON c.teacher_id = t.teacher_id WHERE course_id = @cid";
            cmd.Parameters.AddWithValue("@cid", course.courseId);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            string TeacherName = reader["Teacher_Name"];
            return TeacherName;
        }

        public bool UpdateCourseInfo(int CourseCode, string CourseName, string instructor)
        {
            //course.courseCode = CourseCode;
            //course.courseName = CourseName;
            //course.instructorName = instructor;
            //return true;
        }
    }
}

