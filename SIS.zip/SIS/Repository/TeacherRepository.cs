﻿using System;
using SIS.Model;

namespace SIS.Repository
{
	public class TeacherRepository
	{
		Teacher teacher;

		public void UpdateTeacherInfo()
		{


		}

        public void DisplayTeacherInfo()
		{


		}


        public void GetAssignedCourses()
		{
            //list of courses assigned to a teacher
            List<Course> course = new List<Course>();
            cmd.CommandText = "select * from Course c JOIN Teacher t ON c.teacher_id = t.teacher_id WHERE teacher_id = @tid";
            cmd.Parameters.AddWithValue("@tid", teacher.teacherId);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                student.studentId = (int)reader["student_id"];
                student.firstName = (string)reader["first_name"];
                student.lastName = (string)reader["last_name"];
                student.dob = (string)reader["date_of_birth"]; //error can be here
                student.email = (string)reader["email"];
                student.phoneNumber = (int)reader["phone_number"];


            }
            sqlConnection.Close();



        }

        public TeacherRepository()
		{
		}
	}
}

