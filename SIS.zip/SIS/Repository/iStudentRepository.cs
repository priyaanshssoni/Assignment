﻿using System;
using SIS.Model;

namespace SIS.Repository
{
	public interface iStudentRepository
	{
        Boolean EnrollInCourse(Course course);

        Boolean UpdateStudentInfo(string firstName, string lastName, DateTime dateOfBirth, string email, string phoneNumber);

        Boolean MakePayment(Payment payment);

        List<Student> DisplayStudentInfo();

        List<Enrollment> GetEnrolledCourses();

        List<Payment> GetPaymentHistory();
    }
}

