﻿using System;
using SIS.Model;

namespace SIS.Repository
{
	public interface iCourseRepository
	{

    bool      AssignTeacher(Teacher teacher);
    bool      UpdateCourseInfo(int CourseCode, string CourseName, string instructor);
    List<Course>    DisplayCourseInfo();
    List<Enrollment>    GetEnrollments();
    Teacher  GetTeacher();

    }
}

