﻿using System;
using SIS.Model;

namespace SIS.Repository
{
    public class EnrollmentRepository : iEnrollmentRepository
	{
		Student s1;
		public string GetStudent(Enrollment enroll)
		{
            cmd.CommandText = "select concat (s.first_name + ' ' , s.last_name) as Student_Name from Student s JOIN Enrollments e ON s.student_id = e.student_id WHERE enrollment_id = @eid";
            cmd.Parameters.AddWithValue("@eid", enroll.enrollId);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            string StudentName = reader["Student_Name"];
            return StudentName;
        }

		public string GetCourse(Enrollment enroll)
		{
            cmd.CommandText = "select course_name from Courses c JOIN Enrollments e ON c.course_id = e.course_id WHERE enrollment_id = @eid";
            cmd.Parameters.AddWithValue("@eid", enroll.enrollId);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            string CName = reader["course_name"];
            return CName;
        }

        public EnrollmentRepository()
        {
        }
    }




	
}

