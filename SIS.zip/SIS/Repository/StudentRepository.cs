﻿using System;
using System.Runtime.ConstrainedExecution;
using SIS.Model;

namespace SIS.Repository

{
	public class StudentRepository : iStudentRepository
	{
        Student student;
        //Add Student Method
        //Delete Student Method

        public Boolean EnrollInCourse(Course course)
        {
            //clearing paramateres
            //cmd.Parameters.Clear()
            cmd.CommandText = "INSERT INTO Enrollments VALUES(@course_name,@student_id,@course_id,@enrollment_date)";
            cmd.Parameters.AddWithValue("@course_name",course.courseName);
            cmd.Parameters.AddWithValue("@student_id", student.studentId);
            cmd.Parameters.AddWithValue("@course_id", course.courseId);
            cmd.Parameters.AddWithValue("@enrollment_date",DateTime.Now);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            int addProductStatus = cmd.ExecuteNonQuery();
            return addProductStatus;

        }

        public Boolean MakePayment(Payment payment)
        {
            //clearing paramateres
            //cmd.Parameters.Clear()
            cmd.CommandText = "INSERT INTO Payments VALUES(@student_id,@amount,@payment_date)";
            cmd.Parameters.AddWithValue("@student_id", student.studentId);
            cmd.Parameters.AddWithValue("@amount", payment.amount);
            cmd.Parameters.AddWithValue("@payment_date", DateTime.Now);
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            int addProductStatus = cmd.ExecuteNonQuery();
            return addProductStatus;
        }

        public List<Student> DisplayStudentInfo()
        {
            List<Student> studentt = new List<Student>();
            cmd.CommandText = "SELECT * FROM Students";
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                student.studentId = (int)reader["student_id"];
                student.firstName = (string)reader["first_name"];
                student.lastName = (string)reader["last_name"];
                student.dob = (string)reader["date_of_birth"]; //error can be here
                student.email = (string)reader["email"];
                student.phoneNumber = (int)reader["phone_number"];


            }
            sqlConnection.Close();
            return studentt;
        }

        public Boolean UpdateStudentInfo( string firstName, string lastName, DateTime dateOfBirth, string email, string phoneNumber)
        {
            //Update SQL Command will be used

            //student.firstName = firstName;
            //student.lastName = lastName;
            //student.dob = dateOfBirth;
            //student.email = email;
            //student.phoneNumber = phoneNumber;
            //return true;
        }

        public List<Payment> GetPaymentHistory()
        {
            List<Payment> pay = new List<Payment>();
            cmd.CommandText = "SELECT * FROM Payments";
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Payment payee = new Payment();
                payee.paymentId = (int)reader["payment_id"];
                payee.studentId = (string)reader["student_id"];
                payee.amount = (int)reader["amount"];
                payee.paymentDate = (int)reader["payment_date"];

            }
            sqlConnection.Close();
            return pay;

        }

        public List<Enrollment> GetEnrolledCourses()
        {
            List<Enrollment> enroll = new List<Enrollment>();
            cmd.CommandText = "SELECT * FROM Enrollments";
            cmd.Connection = sqlConnection;
            sqlConnection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Enrollment enrol = new Enrollment();
                enrol.enrollId = (int)reader["enrollment_id"];
                enrol.course = (string)reader["course_name"];
                enrol.courseId = (int)reader["course_id"];
                enrol.enrollDate = (int)reader["enrollment_date"];

            }
            sqlConnection.Close();
            return enroll;
        }


        public StudentRepository()
        {
            
        }
        public StudentRepository(int StudentId, string FirstName, string LastName,
        DateTime Dob, string Email, string PhoneNumber)
        {
            student.studentId = StudentId;
            student.firstName = FirstName;
            student.lastName = LastName;
            student.dob = Dob;
            student.email = Email;
            student.phoneNumber = PhoneNumber;
        }
    }






        //public bool DisplayStudentInfo()
        //{
        //    throw new NotImplementedException();
        //}

        //public bool EnrollInCourse()
        //{
        //    throw new NotImplementedException();
        //}

        //public bool GetEnrolledCourses()
        //{
        //    throw new NotImplementedException();
        //}

        //public bool GetPaymentHistory()
        //{
        //    throw new NotImplementedException();
        //}

        //public bool MakePayment()
        //{
        //    throw new NotImplementedException();
        //}

        //public bool UpdateStudentInfo()
        //{
        //    throw new NotImplementedException();
        //}
    }
