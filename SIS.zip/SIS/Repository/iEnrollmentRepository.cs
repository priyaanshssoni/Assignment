﻿using System;
using SIS.Model;

namespace SIS.Repository
{
	

	public interface iEnrollmentRepository
	{

        void GetStudent(Enrollment enroll);
        void GetCourse(Enrollment enroll);
    }
}

