﻿using System;
namespace SIS.Model
{
	public class Enrollment
    {



        public int enrollId
        {
            get { return enrollId; } //read only property
            set { enrollId = value; } //write only property
        }

        public int studentId
        {
            get { return studentId; } //read only property
            set { studentId = value; } //write only property
        }

        public int courseId
        {
            get { return courseId; } //read only property
            set { courseId = value; } //write only property
        }

        public DateTime enrollDate
        {
            get { return enrollDate; } //read only property
            set { enrollDate = value; } //write only property
        }

        public Student student
        {
            get { return student; } //read only property
            set { student = value; } //write only property
        }

        public Course course
        {
            get { return course; } //read only property
            set { course = value; } //write only property
        }



        public Enrollment()
        {

        }

        public Enrollment( int EId,int StudentId,int CourseId,DateTime EnrollDate)
		{
            enrollId = EId;
            studentId = StudentId;
            courseId = CourseId;
            enrollDate = EnrollDate;
           

		}
	}
}

