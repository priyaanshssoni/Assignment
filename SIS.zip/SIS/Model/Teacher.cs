﻿using System;
namespace SIS.Model
{
	public class Teacher
	{
      //  int teacherId;
     //   string firstName;
     //   string lastName;
   //     string email;


        public int teacherId
        {
            get { return teacherId; } //read only property
            set { teacherId = value; } //write only property
        }

        public string firstName
        {
            get { return firstName; } //read only property
            set { firstName = value; } //write only property
        }

        public string lastName
        {
            get { return lastName; } //read only property
            set { lastName = value; } //write only property
        }
        public string email
        {
            get { return email; } //read only property
            set { email = value; } //write only property
        }


        public Teacher(int TeacherId,string FirstName,string LastName,string Email)
		{
            teacherId = TeacherId;
            firstName = FirstName;
            lastName = LastName;
            email = Email;

		}
	}
}

