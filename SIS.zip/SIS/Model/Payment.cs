﻿using System;
namespace SIS.Model
{
	public class Payment
	{
       


        public int paymentId
        {
            get { return paymentId; } //read only property
            set { paymentId = value; } //write only property
        }
        public int studentId
        {
            get { return studentId; } //read only property
            set { studentId = value; } //write only property
        }
        public decimal amount
        {
            get { return amount; } //read only property
            set { amount = value; } //write only property
        }
        public DateTime paymentDate
        {
            get { return paymentDate; } //read only property
            set { paymentDate = value; } //write only property


        }

        public Student student

        {
            get { return student; } //read only property
            set { student = value; } //write only property
        }

        public Payment()
        {

        }

        public Payment(int PaymentId,int StudentId,decimal Amount,DateTime PaymentDate)
		{
            paymentId = PaymentId;
            studentId = StudentId;
            amount = Amount;
            paymentId = PaymentId;
		}
	}
}

