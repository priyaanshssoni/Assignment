﻿using System;
namespace SIS.Model
{
	public class Course
	{
		//int courseId;
		//string courseName;
		//int courseCode;
		//string instructorName;


        public int courseId
        {
            get { return courseId; } //read only property
            set { courseId = value; } //write only property
        }

        public string courseName
        {
            get { return courseName; } //read only property
            set { courseName = value; } //write only property
        }

        public int courseCode
        {
            get { return courseCode; } //read only property
            set { courseCode = value; } //write only property
        }

        public string instructorName
        {
            get { return instructorName; } //read only property
            set { instructorName = value; } //write only property
        }

        public Course()
        {

        }
        public Course(int CourseId,
		string CourseName,
		int CourseCode,
		string InstructorName)
		{
            courseId = CourseId;
            courseName = CourseName;
            courseCode = CourseCode;
            instructorName = InstructorName;
		}

	}
}

