﻿using System;
namespace SIS.Model
{
	public class Student
	{

        public int studentId
        {
            get { return studentId; } //read only property
            set { studentId = value; } //write only property
        }

        public string firstName
        {
            get { return firstName; } //read only property
            set { firstName = value; } //write only property
        }

        public string lastName
        {
            get { return lastName; } //read only property
            set { lastName = value; } //write only property
        }

        public DateOnly dob
        {
            get { return dob; } //read only property
            set { dob = value; } //write only property
        }

        public string email
        {
            get { return email; } //read only property
            set { email = value; } //write only property
        }

        public string phoneNumber
        {
            get { return phoneNumber; } //read only property
            set { phoneNumber = value; } //write only property
        }


        public Student()
        {

        }
        public Student(int StudentId,string FirstName, string LastName,
        DateTime Dob,string Email, string PhoneNumber)
		{
			studentId = StudentId;
			firstName = FirstName;
			lastName = LastName;
			dob = Dob;
			email = Email;
			phoneNumber = PhoneNumber;
		}
	}
}



