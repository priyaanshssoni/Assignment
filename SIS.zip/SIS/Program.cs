﻿using SIS.Model;
using SIS.Repository;

namespace SIS;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");

        StudentRepository stud1 = new StudentRepository(1, "abc", "def", DateTime.Now, "abc@", "1234567889");
        Console.WriteLine(stud1.DisplayStudentInfo());
        Console.ReadLine();
    }
}

